﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ImageGallery.Model
{
    public class ApplicationUserProfileForCreation
    { 
        // add additional properties here if needed
    }
}
