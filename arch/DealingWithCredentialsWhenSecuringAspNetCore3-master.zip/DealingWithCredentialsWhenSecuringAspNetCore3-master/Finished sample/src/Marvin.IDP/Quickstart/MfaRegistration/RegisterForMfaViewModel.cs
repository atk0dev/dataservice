﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Marvin.IDP
{
    public class RegisterForMfaViewModel
    {
        public string KeyUri { get; set; }
        public string Secret { get; set; }
    }
}
