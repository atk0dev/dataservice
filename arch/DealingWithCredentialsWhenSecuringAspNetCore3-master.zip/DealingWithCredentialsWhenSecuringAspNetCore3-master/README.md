# Dealing with Credentials when Securing an ASP.NET Core 3 Application
Starter files and fully finished sample code for my Dealing with Credentials when Securing an ASP.NET Core 3 Application course at Pluralsight.

Course can be found here: https://app.pluralsight.com/library/courses/dealing-credentials-when-securing-aspdotnet-core-3-application/table-of-contents
